package com.cg.sprint2.payment.exceptions;

public class UserNotFoundException extends Throwable {

}
